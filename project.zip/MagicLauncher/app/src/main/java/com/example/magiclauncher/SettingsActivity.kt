package com.example.magiclauncher

import android.app.*
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var col: LinearLayout
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun put(f: SharedPreferences.Editor.() -> Unit) = p.edit().apply(f).putBoolean("dirty", true).apply()
    private fun tv(t: String, sz: Float, c: Int) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        p = getSharedPreferences("launcher", MODE_PRIVATE)
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(48)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF101418.toInt()); addView(col) })
        col.addView(tv("Launcher settings", 26f, Color.WHITE))
        head("Icons")
        slider("Icon size", "icon", 36, 80, 54, "dp"); slider("Label size", "label", 8, 16, 11, "sp")
        toggle("Show labels", "labels", true); toggle("Dark labels", "dark", false)
        choice("Icon shape", "shape", listOf("Original", "Circle", "Squircle", "Rounded square", "Square"), 0)
        head("Home screen")
        slider("Columns (0 = auto)", "cols", 0, 12, 0, ""); slider("Rows (0 = auto)", "rows", 0, 10, 0, "")
        toggle("Lock layout", "lock", false); toggle("Show page dots", "dots", true)
        choice("Page transition", "trans", listOf("Parallax fade", "Zoom", "Slide", "Rotate", "Depth"), 0)
        head("Dock")
        toggle("Show dock", "dock", true); toggle("Show recent apps", "recs", true)
        slider("Blur strength", "blur", 1, 8, 3, ""); slider("Tint opacity", "tint", 0, 100, 19, "%"); slider("Corner radius", "dr", 0, 44, 30, "dp")
        head("Folders")
        slider("Folder opacity", "fop", 30, 100, 92, "%")
        head("Animations")
        slider("Animation speed", "anim", 0, 200, 100, "%")
        head("More")
        button("Set as default home app") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        button("Show hidden apps") { put { remove("hidden") }; Toast.makeText(this, "Hidden apps restored", Toast.LENGTH_SHORT).show() }
        button("Reset home layout") {
            AlertDialog.Builder(this).setTitle("Reset layout?").setMessage("Icons, folders and dock go back to default. Widgets stay in the list until removed.")
                .setPositiveButton("Reset") { _, _ -> put { remove("items"); remove("favs"); remove("recents") } }.setNegativeButton("Cancel", null).show()
        }
    }

    private fun head(t: String) = col.addView(tv(t.uppercase(), 13f, 0xFF7FB7FF.toInt()).apply { setPadding(0, dp(28), 0, dp(8)) })
    private fun toggle(t: String, k: String, d: Boolean) = col.addView(Switch(this).apply {
        text = t; textSize = 16f; setTextColor(Color.WHITE); isChecked = p.getBoolean(k, d); setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, b -> put { putBoolean(k, b) } }
    })
    private fun slider(t: String, k: String, lo: Int, hi: Int, d: Int, u: String) {
        val v = p.getInt(k, d); val lab = tv("$t: $v$u", 16f, Color.WHITE).apply { setPadding(0, dp(10), 0, 0) }
        col.addView(lab)
        col.addView(SeekBar(this).apply {
            max = hi - lo; progress = v - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, user: Boolean) { lab.text = "$t: ${pr + lo}$u"; put { putInt(k, pr + lo) } }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })
    }
    private fun choice(t: String, k: String, opts: List<String>, d: Int) {
        val b = tv("$t: ${opts[p.getInt(k, d)]}", 16f, Color.WHITE).apply { setPadding(0, dp(14), 0, dp(14)) }
        b.setOnClickListener { AlertDialog.Builder(this).setTitle(t).setItems(opts.toTypedArray()) { _, i -> put { putInt(k, i) }; b.text = "$t: ${opts[i]}" }.show() }
        col.addView(b)
    }
    private fun button(t: String, run: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { run() } })
}
