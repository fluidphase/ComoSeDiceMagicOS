package com.example.magiclauncher

import android.Manifest
import android.app.*
import android.appwidget.*
import android.content.*
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

data class App(val label: String, val pkg: String, val cn: ComponentName, val icon: Drawable)
class Item(val kind: String, var key: String, var pkgs: MutableList<String> = mutableListOf(), var page: Int = 0, var c: Int = 0, var r: Int = 0, var sc: Int = 1, var sr: Int = 1)
class E(val t: String, val red: Boolean = false, val run: () -> Unit)

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val RC_PICK = 1; private val RC_CFG = 2; private val RC_PERM = 3
    private lateinit var host: AppWidgetHost
    private lateinit var mgr: AppWidgetManager
    private lateinit var prefs: SharedPreferences
    private lateinit var pager: ViewPager2
    private lateinit var rootView: FrameLayout
    private lateinit var dock: LinearLayout
    private lateinit var favBox: LinearLayout
    private lateinit var recBox: LinearLayout
    private lateinit var divider: View
    private lateinit var dots: LinearLayout
    private var apps = listOf<App>()
    private var items = mutableListOf<Item>()
    private var favs = mutableListOf<String>()
    private var recents = mutableListOf<String>()
    private var dragItem: Item? = null
    private var dropped: Item? = null
    private var extra = false
    private var edgeDir = 0
    private var menu: PopupWindow? = null
    private var overlay: View? = null
    private val animated = mutableSetOf<Int>()
    private val edge = Runnable { pager.setCurrentItem(pager.currentItem + edgeDir, true); edgeDir = 0 }
    private val pkgReceiver = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = sync() }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun pi(k: String, d: Int) = prefs.getInt(k, d)
    private fun pb(k: String, d: Boolean) = prefs.getBoolean(k, d)
    private fun T(ms: Long) = ms * pi("anim", 100) / 100
    private fun lcol() = if (pb("dark", false)) 0xFF222222.toInt() else Color.WHITE
    private fun cols() = pi("cols", 0).let { if (it > 0) it.coerceIn(3, 12) else max(4, resources.displayMetrics.widthPixels / dp(96)) }
    private fun rows() = pi("rows", 0).let { if (it > 0) it.coerceIn(2, 10) else max(3, (resources.displayMetrics.heightPixels - dp(260)) / dp(100)) }
    private fun pageCount() = max(1, (items.maxOfOrNull { it.page } ?: 0) + 1)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        host = object : AppWidgetHost(this, 1024) {
            override fun onCreateView(c: Context, id: Int, info: AppWidgetProviderInfo?): AppWidgetHostView = WHost(c)
        }
        mgr = AppWidgetManager.getInstance(this)
        val root = FrameLayout(this); rootView = root
        @Suppress("DEPRECATION")
        root.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        pager = ViewPager2(this).apply {
            adapter = Pages(); offscreenPageLimit = 1
            setPageTransformer { p, pos ->
                val a = abs(pos); p.alpha = 1f; p.scaleX = 1f; p.scaleY = 1f; p.rotationY = 0f
                when (pi("trans", 0)) {
                    0 -> { p.alpha = 1 - a * .5f; p.scaleX = 1 - a * .08f; p.scaleY = p.scaleX }
                    1 -> { p.alpha = 1 - a; p.scaleX = 1 - a * .3f; p.scaleY = p.scaleX }
                    3 -> { p.pivotX = if (pos < 0) p.width.toFloat() else 0f; p.pivotY = p.height / 2f; p.rotationY = -pos * 35f; p.alpha = 1 - a * .6f }
                    4 -> { p.alpha = 1 - a * .8f; p.scaleX = 1 - a * .2f; p.scaleY = p.scaleX }
                }
            }
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() { override fun onPageSelected(p: Int) = updateDots(p) })
        }
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        favBox = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0) }
        recBox = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), 0, dp(8), 0) }
        divider = View(this).apply { setBackgroundColor(0x77FFFFFF) }
        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(favBox, LinearLayout.LayoutParams(WRAP, MATCH)); addView(divider, LinearLayout.LayoutParams(dp(1), dp(36)).apply { setMargins(dp(8), 0, dp(8), 0) }); addView(recBox, LinearLayout.LayoutParams(WRAP, MATCH))
            setOnDragListener { v, e ->
                val d = dragItem
                when (e.action) {
                    DragEvent.ACTION_DRAG_STARTED -> d?.kind == "app" && favs.size < 6
                    DragEvent.ACTION_DRAG_ENTERED -> { v.animate().scaleX(1.06f).scaleY(1.06f).setDuration(T(150)).start(); true }
                    DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> { v.animate().scaleX(1f).scaleY(1f).setDuration(T(150)).start(); true }
                    DragEvent.ACTION_DROP -> { if (d != null) { items.remove(d); favs.add(d.key); save() }; true }
                    else -> true
                }
            }
        }
        root.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH).apply { bottomMargin = dp(136) })
        root.addView(dots, FrameLayout.LayoutParams(MATCH, dp(20), Gravity.BOTTOM).apply { bottomMargin = dp(112) })
        root.addView(dock, FrameLayout.LayoutParams(WRAP, dp(84), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(24) })
        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { v, i -> v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i }
        setContentView(root)
        registerReceiver(pkgReceiver, IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package") })
        sync()
    }

    override fun onStart() { super.onStart(); host.startListening() }
    override fun onStop() { super.onStop(); host.stopListening(); closeFolder(false) }
    override fun onDestroy() { super.onDestroy(); unregisterReceiver(pkgReceiver) }
    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("dirty", false)) { prefs.edit().putBoolean("dirty", false).apply(); animated.clear(); sync() } else refreshDock()
    }
    @Suppress("OVERRIDE_DEPRECATION") override fun onBackPressed() { closeFolder() }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); menu?.dismiss(); closeFolder(); pager.setCurrentItem(0, true) }
    override fun onConfigurationChanged(n: Configuration) {
        super.onConfigurationChanged(n); closeFolder(false); normalize(); compact(); save(); animated.clear(); refresh()
    }

    // ---------- Model ----------
    private fun defaultFavs(): List<String> {
        val pm = packageManager
        return listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")), Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)).mapNotNull { pm.resolveActivity(it, 0)?.activityInfo?.packageName }.distinct()
    }

    private fun sync() {
        val pm = packageManager
        apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, ComponentName(it.activityInfo.packageName, it.activityInfo.name), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        val ps = apps.map { it.pkg }.toSet(); val hid = hiddenSet()
        val first = prefs.getString("items", null) == null
        items = mutableListOf()
        prefs.getString("items", null)?.let { s ->
            val a = JSONArray(s)
            for (i in 0 until a.length()) { val o = a.getJSONObject(i)
                items.add(Item(o.getString("k"), o.getString("key"), o.getString("p").split(",").filter { it.isNotBlank() }.toMutableList(), o.getInt("pg"), o.getInt("c"), o.getInt("r"), o.getInt("sc"), o.getInt("sr"))) }
        }
        favs = (prefs.getString("favs", null)?.split(",")?.filter { it.isNotBlank() } ?: defaultFavs()).filter { it in ps }.toMutableList()
        recents = prefs.getString("recents", "")!!.split(",").filter { it in ps }.toMutableList()
        items.removeAll { (it.kind == "app" && (it.key !in ps || it.key in hid)) || (it.kind == "widget" && mgr.getAppWidgetInfo(it.key.toInt()) == null) }
        items.filter { it.kind == "folder" }.forEach { it.pkgs.retainAll(ps) }; items.removeAll { it.kind == "folder" && it.pkgs.isEmpty() }
        if (first) {
            Item("clock", "", sc = min(3, cols()), sr = 2).also { place(it); items.add(it) }
            Item("search", "", sc = min(4, cols())).also { place(it); items.add(it) }
        }
        val placed = items.filter { it.kind == "app" }.map { it.key } + items.flatMap { it.pkgs } + favs + hid
        apps.filter { it.pkg !in placed }.forEach { a -> Item("app", a.pkg).also { place(it); items.add(it) } }
        normalize(); compact(); save(); refresh()
    }

    private fun save() {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("k", it.kind).put("key", it.key).put("p", it.pkgs.joinToString(",")).put("pg", it.page).put("c", it.c).put("r", it.r).put("sc", it.sc).put("sr", it.sr)) }
        prefs.edit().putString("items", a.toString()).putString("favs", favs.joinToString(",")).putString("recents", recents.joinToString(",")).apply()
    }

    private fun free(p: Int, c: Int, r: Int, sc: Int, sr: Int, ign: Item?) =
        items.none { it !== ign && it.page == p && c < it.c + it.sc && it.c < c + sc && r < it.r + it.sr && it.r < r + sr }

    private fun place(m: Item) {
        m.sc = min(m.sc, cols()); m.sr = min(m.sr, rows())
        var p = 0
        while (true) {
            for (r in 0..rows() - m.sr) for (c in 0..cols() - m.sc) if (free(p, c, r, m.sc, m.sr, m)) { m.page = p; m.c = c; m.r = r; return }
            p++
        }
    }
    private fun normalize() {
        items.forEach { it.sc = min(it.sc, cols()); it.sr = min(it.sr, rows()) }
        val bad = items.filter { it.c + it.sc > cols() || it.r + it.sr > rows() }
        bad.forEach { it.page = -1 }; bad.forEach { place(it) }
    }
    private fun compact() { val ps = items.map { it.page }.distinct().sorted(); items.forEach { it.page = ps.indexOf(it.page) } }

    private fun refresh() { pager.adapter?.notifyDataSetChanged(); updateDots(pager.currentItem); refreshDock() }

    private fun refreshDock() {
        favBox.removeAllViews(); recBox.removeAllViews()
        dock.visibility = if (pb("dock", true)) View.VISIBLE else View.GONE
        dock.layoutParams = (dock.layoutParams as FrameLayout.LayoutParams).also { it.height = dp(pi("icon", 54) + 30) }
        favs.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }.forEach { a -> favBox.addView(dockIcon(a, true), LinearLayout.LayoutParams(dp(pi("icon", 54) + 10), MATCH)) }
        (if (pb("recs", true)) recents.filter { it !in favs } else emptyList()).mapNotNull { p -> apps.firstOrNull { it.pkg == p } }.forEach { a -> recBox.addView(dockIcon(a, false), LinearLayout.LayoutParams(dp(pi("icon", 54) + 10), MATCH)) }
        val hasRec = recBox.childCount > 0
        recBox.visibility = if (hasRec) View.VISIBLE else View.GONE
        divider.visibility = if (hasRec) View.VISIBLE else View.GONE
        favBox.visibility = if (favBox.childCount > 0) View.VISIBLE else View.GONE
        dock.post { applyDockBlur() }
    }
    private fun dockIcon(a: App, fav: Boolean) = appView(a, false).also { v -> bindLong(v, null) { appEntries(a, dock = fav) } }

    // ---------- Views ----------
    private fun appView(a: App, label: Boolean = true, color: Int = lcol()) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
        addView(iconView(a), LinearLayout.LayoutParams(dp(pi("icon", 54)), dp(pi("icon", 54))))
        if (label && pb("labels", true)) addView(labelView(a.label, color), LinearLayout.LayoutParams(MATCH, WRAP))
        setOnClickListener { launch(a, it) }
    }
    private fun labelView(t: String, color: Int) = TextView(this).apply {
        text = t; setTextColor(color); textSize = pi("label", 11).toFloat(); maxLines = 1; gravity = Gravity.CENTER
        ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(dp(2), dp(4), dp(2), 0)
        if (color == Color.WHITE) setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
    }

    private fun folderView(m: Item) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
        val tile = android.widget.GridLayout(context).apply {
            columnCount = 2; setPadding(dp(5), dp(5), dp(5), dp(5))
            background = GradientDrawable().apply { setColor(0x55FFFFFF); cornerRadius = dp(15).toFloat() }
        }
        m.pkgs.take(4).mapNotNull { p -> apps.firstOrNull { it.pkg == p } }.forEach { a ->
            tile.addView(ImageView(context).apply { setImageDrawable(a.icon) },
                android.widget.GridLayout.LayoutParams().apply { width = dp((pi("icon", 54) - 18) / 2); height = dp((pi("icon", 54) - 18) / 2); setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        addView(tile, LinearLayout.LayoutParams(dp(pi("icon", 54)), dp(pi("icon", 54))))
        addView(labelView(m.key, lcol()), LinearLayout.LayoutParams(MATCH, WRAP))
        setOnClickListener { openFolder(m, tile) }
    }

    private fun clockView() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), 0)
        addView(TextClock(context).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"; textSize = 46f; setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 1f, 0x66000000); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        })
        addView(TextClock(context).apply { format12Hour = "EEEE, MMMM d"; format24Hour = "EEEE, MMMM d"; textSize = 14f; setTextColor(Color.WHITE) })
    }

    private fun searchView() = FrameLayout(this).apply {
        addView(TextView(context).apply {
            text = "G   Search"; textSize = 15f; setTextColor(0xFF555555.toInt()); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), 0, dp(20), 0)
            background = GradientDrawable().apply { setColor(0xF2FFFFFF.toInt()); cornerRadius = dp(26).toFloat() }
        }, FrameLayout.LayoutParams(MATCH, dp(48), Gravity.CENTER).apply { setMargins(dp(8), 0, dp(8), 0) })
        setOnClickListener { openSearch() }
    }

    private fun makeView(m: Item): View {
        val v: View = when (m.kind) {
            "app" -> { val a = apps.firstOrNull { it.pkg == m.key }
                if (a == null) View(this) else appView(a).also { bindLong(it, m) { appEntries(a, home = m) } } }
            "folder" -> folderView(m).also { bindLong(it, m) { listOf(E("Rename") { rename(m) }, E("Disband folder", true) { disband(m) }) } }
            "widget" -> {
                val id = m.key.toInt(); val info = mgr.getAppWidgetInfo(id)
                if (info == null) View(this) else (host.createView(this, id, info) as WHost).apply {
                    setAppWidget(id, info)
                    outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(20).toFloat()) }
                    clipToOutline = true
                    onLong = { showMenu(this, listOf(E("Remove widget", true) { host.deleteAppWidgetId(id); items.remove(m); save(); refresh() })) }
                    onDrag = { startDrag(m, this) }
                }
            }
            "clock" -> clockView().also { bindLong(it, m) { listOf(E("Remove clock", true) { items.remove(m); save(); refresh() }) } }
            else -> searchView().also { bindLong(it, m) { listOf(E("Remove search bar", true) { items.remove(m); save(); refresh() }) } }
        }
        v.tag = m
        if (m === dropped) { dropped = null; v.scaleX = 1.25f; v.scaleY = 1.25f; v.animate().scaleX(1f).scaleY(1f).setDuration(T(280)).setInterpolator(OvershootInterpolator(2f)).start() }
        if (m === dragItem) v.alpha = .3f
        return v
    }

    private fun bindLong(v: View, m: Item?, entries: () -> List<E>) {
        var dx = 0f; var dy = 0f; var lp = false
        v.setOnLongClickListener { lp = true; it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); showMenu(it, entries()); true }
        v.setOnTouchListener { w, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; lp = false; w.animate().scaleX(.88f).scaleY(.88f).setDuration(T(90)).start() }
                MotionEvent.ACTION_MOVE -> if (lp && m != null && hypot(e.rawX - dx, e.rawY - dy) > dp(10)) { lp = false; menu?.dismiss(); startDrag(m, w) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> w.animate().scaleX(1f).scaleY(1f).setDuration(T(260)).setInterpolator(OvershootInterpolator(3f)).start()
            }; false
        }
    }

    private fun launch(a: App, v: View) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(i, ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle())
            recents.remove(a.pkg); recents.add(0, a.pkg); while (recents.size > 4) recents.removeAt(4); save()
        } catch (e: Exception) { Toast.makeText(this, "Can't open ${a.label}", Toast.LENGTH_SHORT).show() }
    }

    // ---------- Menus ----------
    private fun appEntries(a: App, home: Item? = null, folder: Item? = null, dock: Boolean = false): List<E> {
        val l = mutableListOf<E>()
        if (Build.VERSION.SDK_INT >= 25) try {
            val la = getSystemService(LauncherApps::class.java)
            val q = LauncherApps.ShortcutQuery().setPackage(a.pkg).setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
            la.getShortcuts(q, Process.myUserHandle())?.take(4)?.forEach { s -> l.add(E(s.shortLabel.toString()) { la.startShortcut(s, null, null) }) }
        } catch (_: Exception) {}
        if (home != null && favs.size < 6) l.add(E("Add to dock") { items.remove(home); favs.add(a.pkg); save(); refresh() })
        if (dock) l.add(E("Remove from dock") { favs.remove(a.pkg); Item("app", a.pkg).also { place(it); items.add(it) }; save(); refresh() })
        if (folder != null) l.add(E("Remove from folder") {
            closeFolder(false); folder.pkgs.remove(a.pkg); if (folder.pkgs.isEmpty()) items.remove(folder)
            Item("app", a.pkg).also { place(it); items.add(it) }; save(); refresh() })
        if (home != null) l.add(E("Hide app") { hide(a.pkg) })
        l.add(E("App info") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))) })
        l.add(E("Uninstall", true) { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) })
        return l
    }

    private fun showMenu(anchor: View, entries: List<E>) {
        if (entries.isEmpty()) return
        menu?.dismiss()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(6), dp(6), dp(6)); elevation = dp(12).toFloat()
            background = GradientDrawable().apply { setColor(0xF2FFFFFF.toInt()); cornerRadius = dp(22).toFloat() }
        }
        val pw = PopupWindow(box, dp(210), WRAP, true).apply { setBackgroundDrawable(ColorDrawable(0)); elevation = dp(12).toFloat() }
        entries.forEach { e -> box.addView(TextView(this).apply {
            text = e.t; textSize = 15f; setTextColor(if (e.red) 0xFFD32F2F.toInt() else 0xFF222222.toInt()); setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { pw.dismiss(); e.run() } }) }
        box.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels; val sh = resources.displayMetrics.heightPixels; val mh = box.measuredHeight
        val big = anchor.height > dp(300)
        val below = !big && loc[1] + anchor.height + mh < sh - dp(130)
        val x = if (big) (sw - dp(210)) / 2 else (loc[0] + anchor.width / 2 - dp(105)).coerceIn(dp(8), sw - dp(218))
        val y = (if (big) (sh - mh) / 2 else if (below) loc[1] + anchor.height else loc[1] - mh).coerceAtLeast(dp(30))
        box.pivotX = dp(105).toFloat(); box.pivotY = if (below) 0f else mh.toFloat()
        box.scaleX = .7f; box.scaleY = .7f; box.alpha = 0f
        pw.showAtLocation(anchor, Gravity.TOP or Gravity.START, x, y)
        box.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(T(220)).setInterpolator(OvershootInterpolator(1.4f)).start()
        menu = pw
    }

    // ---------- Hide, shapes, search ----------
    private fun hiddenSet() = prefs.getString("hidden", "")!!.split(",").filter { it.isNotBlank() }.toSet()
    private fun hide(pk: String) {
        prefs.edit().putString("hidden", (hiddenSet() + pk).joinToString(",")).apply()
        items.removeAll { it.kind == "app" && it.key == pk }; favs.remove(pk); save(); refresh()
    }
    private fun iconView(a: App) = ImageView(this).apply {
        setImageDrawable(a.icon)
        val sh = pi("shape", 0)
        if (sh > 0) {
            outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) {
                val r = when (sh) { 1 -> v.width / 2f; 2 -> v.width * .32f; 3 -> v.width * .2f; else -> 0f }
                o.setRoundRect(0, 0, v.width, v.height, r) } }
            clipToOutline = true; scaleType = ImageView.ScaleType.CENTER_CROP
        }
    }

    private fun openSearch() {
        closeFolder(false)
        val scrim = FrameLayout(this).apply { setBackgroundColor(0xAA000000.toInt()); setOnClickListener { closeFolder() }; alpha = 0f }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; isClickable = true; setPadding(dp(16), dp(16), dp(16), dp(8)); elevation = dp(16).toFloat()
            background = GradientDrawable().apply { setColor(0xF5FFFFFF.toInt()); cornerRadius = dp(28).toFloat() }
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val et = EditText(this).apply { hint = "Search apps or the web"; setSingleLine(); setTextColor(0xFF222222.toInt()); imeOptions = EditorInfo.IME_ACTION_SEARCH }
        fun fill(q: String) {
            list.removeAllViews()
            val res = if (q.isBlank()) recents.mapNotNull { pk -> apps.firstOrNull { it.pkg == pk } } else apps.filter { it.label.contains(q, true) }.take(8)
            res.forEach { a -> list.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
                addView(ImageView(context).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(40), dp(40)))
                addView(TextView(context).apply { text = a.label; textSize = 16f; setTextColor(0xFF222222.toInt()); setPadding(dp(14), 0, 0, 0) })
                setOnClickListener { launch(a, it); closeFolder(false) }
            }) }
            if (q.isNotBlank()) list.addView(TextView(this).apply {
                text = "Search the web for $q"; textSize = 16f; setTextColor(0xFF1A6FD6.toInt()); setPadding(dp(8), dp(14), dp(8), dp(14))
                setOnClickListener { closeFolder(false); try { startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
            })
        }
        fill("")
        et.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { fill(s.toString()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        et.setOnEditorActionListener { _, _, _ -> apps.firstOrNull { it.label.contains(et.text.toString(), true) }?.let { launch(it, et); closeFolder(false) }; true }
        box.addView(et); box.addView(list)
        scrim.addView(box, FrameLayout.LayoutParams(min(dp(520), resources.displayMetrics.widthPixels - dp(32)), WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(80) })
        rootView.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH)); overlay = scrim
        scrim.animate().alpha(1f).setDuration(T(180)).start()
        box.translationY = -dp(40).toFloat(); box.animate().translationY(0f).setDuration(T(300)).setInterpolator(OvershootInterpolator(1.2f)).start()
        et.requestFocus(); et.postDelayed({ getSystemService(InputMethodManager::class.java).showSoftInput(et, 0) }, 250)
    }

    // ---------- Folders ----------
    private fun openFolder(f: Item, anchor: View) {
        closeFolder(false)
        val scrim = FrameLayout(this).apply { setBackgroundColor(0x66000000); setOnClickListener { closeFolder() }; alpha = 0f }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; isClickable = true
            setPadding(dp(12), dp(16), dp(12), dp(16)); elevation = dp(16).toFloat()
            background = GradientDrawable().apply { setColor((pi("fop", 92) * 255 / 100 shl 24) or 0xFFFFFF); cornerRadius = dp(32).toFloat() }
        }
        panel.addView(TextView(this).apply {
            text = f.key; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF222222.toInt()); setPadding(dp(12), dp(4), dp(12), dp(12))
            setOnClickListener { closeFolder(false); rename(f) }
        })
        val grid = android.widget.GridLayout(this).apply { columnCount = 3 }
        f.pkgs.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }.forEach { a ->
            val v = appView(a, true, 0xFF222222.toInt()); bindLong(v, null) { appEntries(a, folder = f) }
            grid.addView(v, android.widget.GridLayout.LayoutParams().apply { width = dp(84); height = WRAP })
        }
        panel.addView(grid)
        scrim.addView(panel, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        rootView.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH)); overlay = scrim
        scrim.animate().alpha(1f).setDuration(T(180)).start()
        panel.post {
            val a = IntArray(2); anchor.getLocationOnScreen(a); val p = IntArray(2); panel.getLocationOnScreen(p)
            panel.translationX = a[0] + anchor.width / 2f - (p[0] + panel.width / 2f)
            panel.translationY = a[1] + anchor.height / 2f - (p[1] + panel.height / 2f)
            panel.scaleX = .25f; panel.scaleY = .25f
            panel.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(T(320)).setInterpolator(OvershootInterpolator(1.1f)).start()
        }
    }
    private fun closeFolder(animate: Boolean = true) {
        val ov = overlay ?: return; overlay = null
        rootView.windowToken?.let { getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(it, 0) }
        if (animate) ov.animate().alpha(0f).setDuration(T(180)).withEndAction { rootView.removeView(ov) }.start() else rootView.removeView(ov)
    }
    private fun rename(f: Item) {
        val et = EditText(this).apply { setText(f.key); setSelectAllOnFocus(true) }
        AlertDialog.Builder(this).setTitle("Rename folder").setView(et)
            .setPositiveButton("OK") { _, _ -> f.key = et.text.toString().ifBlank { "Folder" }; save(); refresh() }.setNegativeButton("Cancel", null).show()
    }
    private fun disband(f: Item) {
        items.remove(f); f.pkgs.forEach { p -> Item("app", p).also { place(it); items.add(it) } }; save(); refresh()
    }

    // ---------- Pages, drag & drop ----------
    private fun updateDots(sel: Int) {
        dots.visibility = if (pb("dots", true)) View.VISIBLE else View.GONE
        dots.removeAllViews()
        for (i in 0 until pageCount()) dots.addView(View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (i == sel) Color.WHITE else 0x66FFFFFF) }
        }, LinearLayout.LayoutParams(dp(if (i == sel) 8 else 6), dp(if (i == sel) 8 else 6)).apply { setMargins(dp(4), 0, dp(4), 0) })
    }

    private fun startDrag(m: Item, v: View) {
        if (pb("lock", false)) { Toast.makeText(this, "Layout is locked", Toast.LENGTH_SHORT).show(); return }
        dragItem = m; v.alpha = .3f; extra = true
        pager.adapter?.notifyItemInserted(pageCount())
        v.startDragAndDrop(ClipData.newPlainText("i", m.kind), View.DragShadowBuilder(v), m, View.DRAG_FLAG_OPAQUE)
    }
    private fun finishDrag() {
        if (dragItem == null && !extra) return
        dragItem = null; extra = false; pager.removeCallbacks(edge); edgeDir = 0; compact(); refresh()
    }
    private fun edgeScroll(x: Float, w: Int) {
        val d = if (x < dp(36)) -1 else if (x > w - dp(36)) 1 else 0
        if (d == 0) { pager.removeCallbacks(edge); edgeDir = 0 }
        else if (d != edgeDir) { edgeDir = d; pager.removeCallbacks(edge); pager.postDelayed(edge, 600) }
    }
    private fun cellOf(g: View, x: Float, y: Float, d: Item): Pair<Int, Int> {
        val cw = g.width / cols(); val ch = g.height / rows()
        return Pair(((x / cw).toInt() - (d.sc - 1) / 2).coerceIn(0, cols() - d.sc), ((y / ch).toInt() - (d.sr - 1) / 2).coerceIn(0, rows() - d.sr))
    }
    private fun drop(g: Grid, x: Float, y: Float): Boolean {
        val d = dragItem ?: return false
        val (c, r) = cellOf(g, x, y, d)
        val occ = items.firstOrNull { it !== d && it.page == g.page && c < it.c + it.sc && it.c < c + d.sc && r < it.r + it.sr && it.r < r + d.sr }
        when {
            occ == null -> { d.page = g.page; d.c = c; d.r = r; dropped = d }
            d.kind == "app" && occ.kind == "folder" -> { occ.pkgs.add(d.key); items.remove(d); dropped = occ }
            d.kind == "app" && occ.kind == "app" -> {
                val f = Item("folder", "Folder", mutableListOf(occ.key, d.key), occ.page, occ.c, occ.r)
                items.remove(d); items.remove(occ); items.add(f); dropped = f
            }
            else -> return false
        }
        save(); return true
    }

    inner class Grid(ctx: Context) : ViewGroup(ctx) {
        var page = 0; var hover: Rect? = null
        private val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x44FFFFFF }
        override fun onMeasure(w: Int, h: Int) {
            setMeasuredDimension(MeasureSpec.getSize(w), MeasureSpec.getSize(h))
            val cw = measuredWidth / cols(); val ch = measuredHeight / rows()
            for (i in 0 until childCount) { val v = getChildAt(i); val m = v.tag as Item
                v.measure(MeasureSpec.makeMeasureSpec(cw * m.sc, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch * m.sr, MeasureSpec.EXACTLY)) }
        }
        override fun onLayout(ch0: Boolean, l: Int, t: Int, r: Int, b: Int) {
            val cw = (r - l) / cols(); val ch = (b - t) / rows()
            for (i in 0 until childCount) { val v = getChildAt(i); val m = v.tag as Item
                v.layout(m.c * cw, m.r * ch, (m.c + m.sc) * cw, (m.r + m.sr) * ch) }
        }
        override fun dispatchDraw(cv: Canvas) {
            hover?.let { val cw = width / cols().toFloat(); val ch = height / rows().toFloat()
                cv.drawRoundRect(it.left * cw + dp(4), it.top * ch + dp(4), it.right * cw - dp(4), it.bottom * ch - dp(4), dp(18).toFloat(), dp(18).toFloat(), hp) }
            super.dispatchDraw(cv)
        }
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v)
    inner class Pages : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = pageCount() + (if (extra) 1 else 0)
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(Grid(this@MainActivity).apply {
            layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            setOnLongClickListener { g ->
                val l = mutableListOf(E("Add widget") { addWidget() })
                if (items.none { it.kind == "clock" }) l.add(E("Add clock") { Item("clock", "", sc = min(3, cols()), sr = 2).also { place(it); items.add(it); save(); refresh() } })
                if (items.none { it.kind == "search" }) l.add(E("Add search bar") { Item("search", "", sc = min(4, cols())).also { place(it); items.add(it); save(); refresh() } })
                l.add(E("Launcher settings") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) })
                l.add(E("Wallpaper") { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")) })
                g.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); showMenu(g, l); true
            }
            setOnDragListener { v, e ->
                val g = v as Grid; val d = dragItem
                when (e.action) {
                    DragEvent.ACTION_DRAG_STARTED -> d != null
                    DragEvent.ACTION_DRAG_LOCATION -> {
                        if (d != null) { val (c, r) = cellOf(g, e.x, e.y, d); g.hover = Rect(c, r, c + d.sc, r + d.sr); g.invalidate(); edgeScroll(e.x, g.width) }; true }
                    DragEvent.ACTION_DRAG_EXITED -> { g.hover = null; g.invalidate(); true }
                    DragEvent.ACTION_DROP -> { g.hover = null; g.invalidate(); drop(g, e.x, e.y) }
                    DragEvent.ACTION_DRAG_ENDED -> { g.hover = null; finishDrag(); true }
                    else -> true
                }
            }
        })
        override fun onBindViewHolder(h: VH, p: Int) {
            val g = h.itemView as Grid; g.page = p; g.removeAllViews()
            val first = animated.add(p)
            items.filter { it.page == p }.forEachIndexed { i, m ->
                val v = makeView(m); g.addView(v)
                if (first) { v.alpha = 0f; v.translationY = dp(24).toFloat(); v.animate().alpha(1f).translationY(0f).setStartDelay(i * 15L).setDuration(T(300)).start() }
            }
        }
    }

    // ---------- Widgets ----------
    inner class WHost(c: Context) : AppWidgetHostView(c) {
        var onLong: (() -> Unit)? = null; var onDrag: (() -> Unit)? = null
        private var fired = false; private var dx = 0f; private var dy = 0f
        private val lp = Runnable { fired = true; performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onLong?.invoke() }
        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { fired = false; dx = e.rawX; dy = e.rawY; postDelayed(lp, 500) }
                MotionEvent.ACTION_MOVE -> if (!fired && hypot(e.rawX - dx, e.rawY - dy) > dp(8)) removeCallbacks(lp)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(lp)
            }
            return fired
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (!fired) return super.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_MOVE -> if (hypot(e.rawX - dx, e.rawY - dy) > dp(10)) { fired = false; menu?.dismiss(); onDrag?.invoke() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> fired = false
            }
            return true
        }
    }

    private fun addWidget() {
        val id = host.allocateAppWidgetId()
        @Suppress("DEPRECATION")
        startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_INFO, ArrayList<Parcelable>())
            .putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_EXTRAS, ArrayList<Parcelable>()), RC_PICK)
    }
    private fun addWidgetItem(id: Int) {
        val info = mgr.getAppWidgetInfo(id) ?: return
        val cw = max(1, pager.width / cols()); val ch = max(1, pager.height / rows())
        val m = Item("widget", id.toString(), sc = ceil(info.minWidth / cw.toFloat()).toInt().coerceIn(1, cols()), sr = ceil(info.minHeight / ch.toFloat()).toInt().coerceIn(1, rows()))
        place(m); items.add(m); dropped = m; save(); refresh(); pager.setCurrentItem(m.page, true)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        val id = d?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (rc == RC_PICK && id != -1) {
            if (res != RESULT_OK) { host.deleteAppWidgetId(id); return }
            if (mgr.getAppWidgetInfo(id)?.configure != null) host.startAppWidgetConfigureActivityForResult(this, id, 0, RC_CFG, null) else addWidgetItem(id)
        } else if (rc == RC_CFG && id != -1) { if (res == RESULT_OK) addWidgetItem(id) else host.deleteAppWidgetId(id) }
    }

    // ---------- Blurred dock (works on Android 10 and under) ----------
    private fun applyDockBlur() {
        if (Build.VERSION.SDK_INT in 27..32 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), RC_PERM)
        val rad = dp(pi("dr", 30)).toFloat()
        val pills = listOf(favBox, recBox)
        pills.forEach { pv ->
            pv.outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, rad) }
            pv.clipToOutline = true
            pv.background = ColorDrawable(0x55FFFFFF) // fallback frosted tint
        }
        try {
            val wp = WallpaperManager.getInstance(this).drawable ?: return
            val s = 8; val dm = resources.displayMetrics; val sw = dm.widthPixels / s; val sh = dm.heightPixels / s
            val full = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888); val c = Canvas(full)
            val sc = max(sw / wp.intrinsicWidth.toFloat(), sh / wp.intrinsicHeight.toFloat())
            c.translate((sw - wp.intrinsicWidth * sc) / 2, (sh - wp.intrinsicHeight * sc) / 2); c.scale(sc, sc)
            wp.setBounds(0, 0, wp.intrinsicWidth, wp.intrinsicHeight); wp.draw(c)
            pills.filter { it.visibility == View.VISIBLE && it.width > 1 }.forEach { pv ->
                val loc = IntArray(2); pv.getLocationOnScreen(loc)
                val x = (loc[0] / s).coerceIn(0, sw - 2); val y = (loc[1] / s).coerceIn(0, sh - 2)
                val crop = Bitmap.createBitmap(full, x, y, (pv.width / s).coerceIn(1, sw - x), (pv.height / s).coerceIn(1, sh - y))
                pv.background = LayerDrawable(arrayOf(BitmapDrawable(resources, blur(crop, pi("blur", 3))), ColorDrawable((pi("tint", 19) * 255 / 100 shl 24) or 0xFFFFFF)))
            }
        } catch (_: Exception) {}
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) { dock.post { applyDockBlur() } }

    private fun blur(src: Bitmap, r: Int): Bitmap {
        val w = src.width; val h = src.height; var px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        repeat(3) { px = box(px, w, h, r, true); px = box(px, w, h, r, false) }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
    private fun box(p: IntArray, w: Int, h: Int, r: Int, horiz: Boolean): IntArray {
        val o = IntArray(p.size); val n = if (horiz) w else h; val m = if (horiz) h else w
        for (j in 0 until m) for (i in 0 until n) {
            var rs = 0; var gs = 0; var bs = 0
            for (k in -r..r) { val q = (i + k).coerceIn(0, n - 1); val c = if (horiz) p[j * w + q] else p[q * w + j]
                rs += (c shr 16) and 255; gs += (c shr 8) and 255; bs += c and 255 }
            val d = 2 * r + 1
            o[if (horiz) j * w + i else i * w + j] = (0xFF shl 24) or ((rs / d) shl 16) or ((gs / d) shl 8) or (bs / d)
        }
        return o
    }
}
